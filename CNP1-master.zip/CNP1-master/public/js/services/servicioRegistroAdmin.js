//esto seria si vamos a crear mas de un vendedor

// const registroAdministrador = (pCedula,pContrasenna) => {

// }